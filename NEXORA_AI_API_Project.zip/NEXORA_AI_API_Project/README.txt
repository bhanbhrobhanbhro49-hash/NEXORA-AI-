NEXORA AI — API setup

IMPORTANT: This project does NOT contain an API key. Create your own key at:
https://platform.openai.com/api-keys

1. Install Node.js 18 or newer on a computer/server.
2. In this folder, run: npm install
3. Copy .env.example to a new file named .env.
4. Open .env and replace put_your_secret_key_here with your real key.
   Keep .env private. Do not send the key in chat or put it in index.html.
5. Run: npm start
6. Test status at http://localhost:3000/api/status
7. Host this server on an HTTPS-capable Node.js host for APK use.
8. In index.html, find: const API_BASE_URL = '';
   Replace it with your deployed backend URL, e.g. https://your-real-host.example
   (use your actual URL, not this example), then rebuild the APK.

ChatGPT subscription and API billing are separate. API requests may cost money.
Image generation also requires model access and available API billing.
The signup screen in this HTML remains a demo; it does not create real user accounts.
