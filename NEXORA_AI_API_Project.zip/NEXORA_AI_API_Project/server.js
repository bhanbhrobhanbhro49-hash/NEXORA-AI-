require('dotenv').config();
const express = require('express');
const cors = require('cors');
const OpenAI = require('openai');
const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));
const PORT = process.env.PORT || 3000;
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
app.get('/api/status', (_req, res) => res.json({ chatConfigured: !!openai }));
app.post('/api/chat', async (req, res) => {
  if (!openai) return res.status(503).json({ error: 'Server par OPENAI_API_KEY set nahi hai.' });
  try {
    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const safeMessages = messages.filter(m => m && ['user','assistant'].includes(m.role) && typeof m.content === 'string').slice(-20);
    if (!safeMessages.length) return res.status(400).json({ error: 'Sawal likhein.' });
    const response = await openai.chat.completions.create({ model: process.env.OPENAI_CHAT_MODEL || 'gpt-4o-mini', messages: [{ role: 'system', content: 'You are NEXORA AI, a helpful assistant. Reply in the language the user uses.' }, ...safeMessages], max_tokens: 1200 });
    res.json({ answer: response.choices?.[0]?.message?.content || 'Jawab nahi mil saka.' });
  } catch (err) {
    console.error('Chat API error:', err.message);
    res.status(500).json({ error: 'AI request fail hui. API key, billing, model access aur server logs check karein.' });
  }
});
app.post('/api/image', async (req, res) => {
  if (!openai) return res.status(503).json({ error: 'Server par OPENAI_API_KEY set nahi hai.' });
  const prompt = typeof req.body.prompt === 'string' ? req.body.prompt.trim().slice(0, 2000) : '';
  if (!prompt) return res.status(400).json({ error: 'Image prompt likhein.' });
  try {
    const result = await openai.images.generate({ model: process.env.OPENAI_IMAGE_MODEL || 'gpt-image-1', prompt, size: '1024x1024' });
    const b64 = result.data?.[0]?.b64_json;
    if (!b64) throw new Error('No image returned');
    res.json({ image: `data:image/png;base64,${b64}` });
  } catch (err) {
    console.error('Image API error:', err.message);
    res.status(500).json({ error: 'Image generate nahi hui. Image model access aur API billing check karein.' });
  }
});
app.listen(PORT, () => console.log(`NEXORA API server running on port ${PORT}`));
